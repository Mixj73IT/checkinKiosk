
# Student Kiosk — Single-Station Check-In/Out System (v1.1.0)

Production-ready Electron app for high-school student check-in/out with alerts, exceptions, admin tools, **zero‑touch installer**, and **auto‑update**.

See `docs/INSTALL_WINDOWS.md` to get started quickly, `docs/ZeroTouch-Guide.md` for kiosk provisioning, and `docs/AutoUpdate-Setup.md` for update hosting.
