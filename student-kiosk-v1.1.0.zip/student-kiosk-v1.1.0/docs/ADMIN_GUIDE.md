
# Admin Guide
- Roles seeded: admin(1234), front_desk(1111), attendance(2222) — change later.
- Panels: Exceptions / Corrections / Roster Import / Config.
- Photos: provide absolute `photo_path` or place files locally and reference them.
