
# Changelog

## 1.1.0
- Integrated zero‑touch NSIS hook (silent install, kiosk provisioning)
- Added electron‑updater wiring + publish config template
- Added docs inside ZIP (install, usage, admin, config, zero‑touch, auto‑update)

## 1.0.0
- Initial production build
